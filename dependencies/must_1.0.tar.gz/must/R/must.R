# the must function

#' Check if the ... paramters are of certain types and 
#' return an error message if they are not. 
#'
#' This function calls the "is.<type>" functions for all the input
#' parameters, and everything that has an "is.<type>" function is
#' a valid type, e.g. "numeric", "matrix", "finite", ...
#'
#' @param types a vector of one or more types. An "is.<type>" needs to be available, or it needs to be a valid class name
#' @param ... variables that need to be checked
must_be = function(types, ...){
	if(!is.vector(types) || !is.character(types) || length(types)==0)
		stop("Input parameter 'types' needs to be a vector of string type names, e.g. c(\"numeric\", \"matrix\").")
	
	vars = list(...)
	names(vars) = as.list(substitute(list(...)))[-1L]
	
	if(length(vars) == 0)
		stop("Variable whose type is to be checked is missing.")
	
	# iterate over variables and make sure 	
	for(i in 1:length(vars)){
		n = names(vars)[i]
		v = vars[[i]]
		
		for(j in 1:length(types)){
			fun = getFunction(paste("is.", types[j], sep=""), mustFind=FALSE)
			
			if(!is.null(fun)){
				# check with an is.<type> function
				if(!fun(v)){
					if(substring(types[j], 1, 1) %in% c("a", "e", "i", "o", "u")){
						stop(paste("Variable '", n, "' needs to be an ", types[j], ".", sep=""))
					} else {				
						stop(paste("Variable '", n, "' needs to be a ", types[j], ".", sep=""))
					}
				}
			} else if(!is(v, types[j])){
				stop(paste("Variable '", n, "' needs to be of type '", types[j], "'.", sep=""))
			}
		}		
	}	
	
	invisible(NULL)		
}

#' A simple wrapper that has the opposite function of \code{must_be}. 
#'
#' The wrapper is provided only for code readability and is equivalent
#' to \code{!must_have(types, ...)}
#'
#' @param types a vector of types
#' @param ... variables that need to be checked
cannot_be = function(type, ...){
	!must_be(type, ...)
}

#' Check if a set of variables is one of the possibilities
#'
#' @param possibilities a vector or list of possibilities for the variables
#' @param ... variables to be checked
must_be_in = function(possibilities, ...){
	p = possibilities
	if(!is.vector(p) || length(p)==0)
		stop("Input parameter 'possibilities' needs to be a vector of possible values.")
	
	vars = list(...)
	names(vars) = as.list(substitute(list(...)))[-1L]
	
	for(i in 1:length(vars)){
		n = names(vars)[i]
		v = vars[[i]]
		
		if(!(v %in% p)){
			if(is.character(p)){
				p.ser = paste("'", paste(p, collapse="', '"), "'", sep="")
			} else {
				p.ser = paste(p, collapse=", ")
			}
			stop(paste("Variable '", n, "' needs to be one of: [", p.ser, "].", sep=""))
		}
	}
}

#' Check if calling function 'fun' on ... will produce
#' the result 'res', otherwise report an error
#'
#' @param fun function name to be called
#' @param res expected result of the function, default is TRUE
#' @param ... variables that need to have the checked property
must_have = function(fun, res=TRUE, ...){
	if(!is.character(fun))
		stop("Function name needs to be a character string")

	f = getFunction(fun)
		
	vars = list(...)
	names(vars) = as.list(substitute(list(...)))[-1L]
	
	# iterate over variables
	for(i in 1:length(vars)){
		n = names(vars)[i]
		v = vars[[i]]	
		
		if(!all(f(v) == res)){
			stop(paste("Variable '", n, "' needs to have ", fun, " = ", res, sep=""))
		}
	}	
}

